import numpy as np
import json
import os
from scipy.io import savemat
from scipy.ndimage import zoom
import nibabel as nib

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
import torchvision

from utils.data import read_scans, QsmPatchData, QsmPatchDataHD, QsmPatchDataBtumor
from models.utils import load_model
from models.unet3d import UNet3D


class QsmPredict:
    
    def __init__(self, cfg, subject_ids):
        self.subject_ids = subject_ids
        self.cfg = cfg
        self.result_path = '../exp/{}/results'.format(self.cfg['run_name'])
        self.data = read_scans(cfg['data_path'], subject_ids, cfg['input_algo'], cfg['output_algo'])
        try:
            self.ops = cfg['output_patch_size']
            self.output_scale = cfg['output_scale']
            self.dset = QsmPatchData(self.data, cfg['input_patch_size'], cfg['output_patch_size'], 
                                  input_scale=cfg['input_scale'], output_scale=cfg['output_scale'], sample_method='other')
            self.inv = lambda x: x
        except: # v2
            self.ops = cfg['dset_args']['output_patch_size']
            self.output_scale = cfg['dset_args']['output_scale']
            self.dset = QsmPatchData(self.data, **cfg['dset_args'], sample_method='other')
            self.inv = np.arctanh if cfg['dset_args']['output_transform'] == 'tanh' else lambda x: x
        
        self.dataloader = torch.utils.data.DataLoader(self.dset, batch_size=cfg['batch_size'], shuffle=False, num_workers=2)
        
        
    def run_net(self, net):
        net.eval()
        device = self.cfg['device']
        self.predicts = [np.zeros(s) for s in self.dset.original_sizes]
        
        with torch.no_grad():
            for i, (batch_input, batch_target, scans, centers) in enumerate(self.dataloader):
                batch_output = net(batch_input.to(device)).cpu().squeeze()
                batch_output = self.inv(batch_output) / self.output_scale
                for output, s, c in zip(batch_output, scans.int(), centers.int()):
                    self.predicts[s][c[0] - self.ops[0]//2 : c[0] + self.ops[0]//2, 
                                     c[1] - self.ops[1]//2 : c[1] + self.ops[1]//2, 
                                     c[2] - self.ops[2]//2 : c[2] + self.ops[2]//2] = \
                    output[:self.ops[0] - (c[0] + self.ops[0]//2 - self.predicts[s].shape[0]),
                           :self.ops[1] - (c[1] + self.ops[1]//2 - self.predicts[s].shape[1]),
                           :self.ops[2] - (c[2] + self.ops[2]//2 - self.predicts[s].shape[2])]
                    
                    
    def save_predicts(self, which_model='best'):
        for d, p, sid in zip(self.data, self.predicts, self.subject_ids):
            print('Saving scan {}...'.format(sid))
            d['predict'] = p
            print(f'Saved: {self.result_path}/subject_{sid}_{which_model}.mat')
            savemat(f'{self.result_path}/subject_{sid}_{which_model}.mat', d, do_compression=True)

            
class QsmPredictHD:
    
    def __init__(self, cfg, nifti_files):
        self.cfg = cfg
        self.nifti_files = nifti_files
        input_patch_size=cfg['dset_args']['input_patch_size']
        input_scale=cfg['dset_args']['input_scale']
        output_transform=cfg['dset_args']['output_transform']
        self.ops = cfg['dset_args']['output_patch_size']
        self.output_scale = cfg['dset_args']['output_scale']
        
        self.dset = QsmPatchDataHD(self.nifti_files, 
                                   input_patch_size, 
                                   self.ops, 
                                   input_scale, 
                                   self.output_scale, 
                                   output_transform)
        
        self.inv = np.arctanh if output_transform == 'tanh' else lambda x: x
        
        self.dataloader = torch.utils.data.DataLoader(self.dset, 
                                                      batch_size=cfg['batch_size'], 
                                                      shuffle=False, 
                                                      num_workers=2)
        
        
    def run_net(self, net):
        net.eval()
        device = self.cfg['device']
        self.predicts = [np.zeros(s) for s in self.dset.interpolated_sizes]
        
        with torch.no_grad():
            for i, (batch_input, scans, centers) in enumerate(self.dataloader):
                batch_output = net(batch_input.to(device)).cpu().squeeze()
                batch_output = self.inv(batch_output) / self.output_scale
                for output, s, c in zip(batch_output, scans.int(), centers.int()):
                    self.predicts[s][c[0] - self.ops[0]//2 : c[0] + self.ops[0]//2, 
                                     c[1] - self.ops[1]//2 : c[1] + self.ops[1]//2, 
                                     c[2] - self.ops[2]//2 : c[2] + self.ops[2]//2] = \
                    output[:self.ops[0] - (c[0] + self.ops[0]//2 - self.predicts[s].shape[0]),
                           :self.ops[1] - (c[1] + self.ops[1]//2 - self.predicts[s].shape[1]),
                           :self.ops[2] - (c[2] + self.ops[2]//2 - self.predicts[s].shape[2])]
                    
    def save_predicts(self):
        for pred, nifti_file, nifti in zip(self.predicts, self.nifti_files, self.dset.data):
            pred = zoom(pred, (1, 1, 0.8))
            output = nib.Nifti1Image(pred, nifti.affine)
            output_filename = nifti_file.split('.')[0] + '_susc_DL.nii.gz'
            print(f'Saving {output_filename}...')
            nib.save(output, output_filename)
            

class QsmPredictBtumor:
    
    def __init__(self, cfg, nifti_files):
        self.cfg = cfg
        self.nifti_files = nifti_files
        input_patch_size=cfg['dset_args']['input_patch_size']
        input_scale=cfg['dset_args']['input_scale']
        output_transform=cfg['dset_args']['output_transform']
        self.ops = cfg['dset_args']['output_patch_size']
        self.output_scale = cfg['dset_args']['output_scale']
        
        self.dset = QsmPatchDataBtumor(self.nifti_files, 
                                       input_patch_size, 
                                       self.ops, 
                                       input_scale, 
                                       self.output_scale, 
                                       output_transform)
        
        self.inv = np.arctanh if output_transform == 'tanh' else lambda x: x
        
        self.dataloader = torch.utils.data.DataLoader(self.dset, 
                                                      batch_size=cfg['batch_size'], 
                                                      shuffle=False, 
                                                      num_workers=2)
        
    def run_net(self, net):
        net.eval()
        device = self.cfg['device']
        self.predicts = [np.zeros(s) for s in self.dset.interpolated_sizes]
        
        with torch.no_grad():
            for i, (batch_input, scans, centers) in enumerate(self.dataloader):
                batch_output = net(batch_input.to(device)).cpu().squeeze()
                batch_output = self.inv(batch_output) / self.output_scale
                for output, s, c in zip(batch_output, scans.int(), centers.int()):
                    self.predicts[s][c[0] - self.ops[0]//2 : c[0] + self.ops[0]//2, 
                                     c[1] - self.ops[1]//2 : c[1] + self.ops[1]//2, 
                                     c[2] - self.ops[2]//2 : c[2] + self.ops[2]//2] = \
                    output[:self.ops[0] - (c[0] + self.ops[0]//2 - self.predicts[s].shape[0]),
                           :self.ops[1] - (c[1] + self.ops[1]//2 - self.predicts[s].shape[1]),
                           :self.ops[2] - (c[2] + self.ops[2]//2 - self.predicts[s].shape[2])]
                    
    def save_predicts(self):
        for pred, nifti_file, nifti in zip(self.predicts, self.nifti_files, self.dset.data):
            output = nib.Nifti1Image(pred, nifti.affine)
            output_filename = nifti_file.split('.')[0] + '_susc_DL2.nii.gz'
            print(f'Saving {output_filename}...')
            nib.save(output, output_filename)
            
    
