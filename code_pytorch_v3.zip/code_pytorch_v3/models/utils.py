import torch
import shutil
import os


def save_model(netG, netD, epoch, val_loss, is_new_best, ckpt_path):
    '''
    Save networks and important information.
    '''
    state_dict = {
                     'epoch': epoch,
                     'netG': netG.state_dict(),
                     'netD': netD.state_dict() if netD else None,
                     'val_loss': val_loss
                 }
    torch.save(state_dict, f=os.path.join(ckpt_path, 'net_last.pt'))
    if is_new_best:
        shutil.copyfile(os.path.join(ckpt_path, 'net_last.pt'), os.path.join(ckpt_path, 'net_best.pt'))
        
    if epoch % 10 == 0:
        shutil.copyfile(os.path.join(ckpt_path, 'net_last.pt'), os.path.join(ckpt_path, f'net_{epoch}.pt'))
         

def load_model(netG, netD, ckpt_path, load_best=True):
    '''
    load generator and necessary data
    '''
    if load_best:
        ckpt_fp = os.path.join(ckpt_path, 'net_best.pt')
    else:
        ckpt_fp = os.path.join(ckpt_path, 'net_last.pt')
    if os.path.isfile(ckpt_fp):
        ckpt = torch.load(ckpt_fp)
        netG.load_state_dict(ckpt['netG'])
        if netD and ckpt['netD']:
            netD.load_state_dict(ckpt['netD'])
            print('netD is also found and loaded.')
        start_epoch = ckpt['epoch'] + 1
        best_val_loss = ckpt['val_loss']
        print(f'Loaded saved checkpoint from {ckpt_fp}, start_epoch={start_epoch}, best_val_loss={best_val_loss}')
    else:
        print('net_best.pt not found, start from scratch.')
        start_epoch = 0
        best_val_loss = 1e10
        
    return netG, netD, start_epoch, best_val_loss
        
