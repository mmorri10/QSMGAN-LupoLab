# change logs:
# 01/17/2019: use LeakyReLU instead of ReLU, avgpool instead of maxpool, add batchnorm
# 03/12/2019: add support for LayerNorm

import torch
from torch import nn
from torch.nn import functional as F


def center_crop_3d(x, crop_shape):
    """
    Crop the center of the tensor. The crop happens on the last 3 dimensions.
    """
    assert len(crop_shape) == 3
    w1, w2, w3 = x.shape[2:]
    c1, c2, c3 = crop_shape
    assert w1 >= c1 and w2 >= c2 and w2 >= c3
    s1, s2, s3 = w1//2-c1//2, w1//2-c2//2, w3//2-c3//2
    e1, e2, e3 = s1+c1, s2+c2, s3+c3
    return x[...,s1:e1,s2:e2,s3:e3]


class ConvBlock(nn.Module):
    """
    A Convolutional Block that consists of two convolution layers each followed by
    instance normalization, relu activation and dropout.
    """

    def __init__(self, in_chans, out_chans, drop_prob, non_lin='ReLU', norm='none'):
        """
        Args:
            in_chans (int): Number of channels in the input.
            out_chans (int): Number of channels in the output.
            drop_prob (float): Dropout probability.
        """
        super().__init__()

        self.in_chans = in_chans
        self.out_chans = out_chans
        self.drop_prob = drop_prob
        self.non_lin = non_lin
        self.norm = norm
        
        layers = []
        layers.append(nn.Conv3d(in_chans, out_chans, kernel_size=3, padding=1))
        if norm == 'BatchNorm':
            layers.append(nn.BatchNorm3d(out_chans))
        elif norm == 'InstanceNorm':
            layers.append(nn.InstanceNorm3d(out_chans))
        elif norm == 'LayerNorm':
            layers.append(nn.LayerNorm(out_chans))
            
        if non_lin == 'ReLU':
            layers.append(nn.ReLU())
        elif non_lin == 'LReLU':
            layers.append(nn.LeakyReLU(0.1))
        
        
        layers.append(nn.Conv3d(out_chans, out_chans, kernel_size=3, padding=1))
        if norm == 'BatchNorm':
            layers.append(nn.BatchNorm3d(out_chans))
        elif norm == 'InstanceNorm':
            layers.append(nn.InstanceNorm3d(out_chans))
        elif norm == 'LayerNorm':
            layers.append(nn.LayerNorm(out_chans))
            
        if non_lin == 'ReLU':
            layers.append(nn.ReLU())
        elif non_lin == 'LReLU':
            layers.append(nn.LeakyReLU(0.1))

        self.layers = nn.Sequential(*layers)

    def forward(self, input):
        """
        Args:
            input (torch.Tensor): Input tensor of shape [batch_size, self.in_chans, height, width]

        Returns:
            (torch.Tensor): Output tensor of shape [batch_size, self.out_chans, height, width]
        """
        return self.layers(input)

    def __repr__(self):
        return f'ConvBlock(in_chans={self.in_chans}, out_chans={self.out_chans}, ' \
            f'drop_prob={self.drop_prob}, non_lin={self.non_lin}, norm={self.norm})'

class UNet3D(nn.Module):
    """
    PyTorch implementation of a U-Net model.

    This is based on:
        Olaf Ronneberger, Philipp Fischer, and Thomas Brox. U-net: Convolutional networks
        for biomedical image segmentation. In International Conference on Medical image
        computing and computer-assisted intervention, pages 234–241. Springer, 2015.
    """

    def __init__(self, in_chans, out_chans, out_shape, chans, num_pool_layers, drop_prob, 
                 non_lin='ReLU', norm=None, tanh=False):
        """
        Args:
            in_chans (int): Number of channels in the input to the U-Net model.
            out_chans (int): Number of channels in the output to the U-Net model.
            chans (int): Number of output channels of the first convolution layer.
            num_pool_layers (int): Number of down-sampling and up-sampling layers.
            drop_prob (float): Dropout probability.
        """
        super().__init__()

        self.in_chans = in_chans
        self.out_chans = out_chans
        self.out_shape = out_shape
        self.chans = chans
        self.num_pool_layers = num_pool_layers
        self.drop_prob = drop_prob

        self.down_sample_layers = nn.ModuleList([ConvBlock(in_chans, chans, drop_prob, non_lin, norm)])
        ch = chans
        for i in range(num_pool_layers - 1):
            self.down_sample_layers += [ConvBlock(ch, ch * 2, drop_prob, non_lin, norm)]
            ch *= 2
        self.conv = ConvBlock(ch, ch, drop_prob, non_lin, norm)

        self.up_sample_layers = nn.ModuleList()
        for i in range(num_pool_layers - 1):
            self.up_sample_layers += [ConvBlock(ch * 2, ch // 2, drop_prob, non_lin, norm)]
            ch //= 2
        self.up_sample_layers += [ConvBlock(ch * 2, ch, drop_prob, non_lin, norm)]
        
        ch = chans * 2 ** (num_pool_layers - 1)
        self.conv_transpose_layers = nn.ModuleList()
        for i in range(num_pool_layers):
            self.conv_transpose_layers += [nn.ConvTranspose3d(ch, ch, kernel_size=2, stride=2)]
            ch //= 2
            
        ch *= 2
        conv2 = [
            nn.Conv3d(ch, out_chans, kernel_size=1),
            nn.Conv3d(out_chans, out_chans, kernel_size=1),
        ]
        if tanh:
            conv2.append(nn.Tanh())
        self.conv2 = nn.Sequential(*conv2)
        
        # initization
        for layer in self.modules():
            if isinstance(layer, nn.Conv3d) or isinstance(layer, nn.ConvTranspose3d):
                nn.init.xavier_uniform_(layer.weight)
                

    def forward(self, input):
        """
        Args:
            input (torch.Tensor): Input tensor of shape [batch_size, self.in_chans, height, width]

        Returns:
            (torch.Tensor): Output tensor of shape [batch_size, self.out_chans, height, width]
        """
        stack = []
        output = input
        # Apply down-sampling layers
        for layer in self.down_sample_layers:
            output = layer(output)
            stack.append(output)
            output = F.avg_pool3d(output, kernel_size=2)

        output = self.conv(output)
        
        # Apply up-sampling layers
        for convtrans, layer in zip(self.conv_transpose_layers, self.up_sample_layers):
#             output = F.interpolate(output, scale_factor=2, mode='trilinear', align_corners=False)
            output = convtrans(output)
            output = torch.cat([output, stack.pop()], dim=1)
            output = layer(output)
            
        # center crop
        output = self.conv2(output)
        output = center_crop_3d(output, self.out_shape)
        return output

    