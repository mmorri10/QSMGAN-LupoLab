import numpy as np
from scipy.io import loadmat
import nibabel as nib
from scipy.ndimage import zoom
import os
import torch
from torch.utils.data import Dataset
    

def read_scans(base_path, ids, input_algo, output_algo):
    '''
    Load all .mat data as a list of dictionaries
    Input:
        base_path: base directory of the dataset
        ids: the .mat basename
        input_algo: the input algorithm, e.g. 'vsharp'
        output_algo: the output algorithm, e.g. 'cosmos'
    '''
    data = []
    for i in ids:
        datapath = os.path.join(base_path, i + '.mat')
        print('Loading {}'.format(datapath))
        temp = loadmat(datapath)
        s = {}
        for key in temp:
            if key == 'mask':
                s[key] = temp[key]
            if key == input_algo:
                s['input'] = temp[input_algo]
            if key == output_algo:
                s['output'] = temp[output_algo]
        del temp
        data.append(s)
    return data


class QsmPatchData(Dataset):
    
    def __init__(self, 
                 data, 
                 input_patch_size, 
                 output_patch_size,
                 input_scale=100, 
                 output_scale=100, 
                 sample_method='train', 
                 sample_gap = 16, 
                 bg_ratio = 0.5, 
                 output_transform='tanh', 
                 data_transform=False):
        '''
        QsmPatchData class to parse QSM dataset.
        Input:
            data: a list of dictionaries loaded using read_scans().
            input_patch_size: target input patch sizes
            output_patch_size: target output patch sizes
            input_scale: the scale factor to normalize the input
            output_scale: the scale factor to normalize the output
            sample_method: 
                'train' -- sample most patches inside the brain mask and a small portion of background patches
                'other' -- divide the entire volume by input patches
        '''
        self.input_patch_size = np.array(input_patch_size)
        if self.input_patch_size.ndim == 1:
            self.input_patch_size = np.expand_dims(self.input_patch_size, 0)
        if len(self.input_patch_size) == 2:
            if self.input_patch_size[0,0] > self.input_patch_size[1,0]:
                self.input_patch_size = self.input_patch_size[::-1,:] # 0-small, 1-large

        self.output_patch_size = np.array(output_patch_size)
        
        assert sample_method in ['train', 'other']
        self.sample_method = sample_method
        
        self.sample_gap = sample_gap if sample_method == 'train' else None
        self.bg_ratio = bg_ratio if sample_method == 'train' else None

        self.original_sizes = [d['input'].shape for d in data]

        self.masks = [d['mask'] for d in data]
        self.inputs = [d['input'] for d in data]
        self.outputs = [d['output'] for d in data]
        
        self.input_scale = input_scale
        self.output_scale = output_scale
#         self.transforms = transforms # todo: data augmentation
 
        self.centers = self._calc_centers()
        self.output_transform = np.tanh if output_transform == 'tanh' else lambda x: x
        
        self.data_transform = data_transform
    
        
    def _calc_centers(self):
        '''
        Calculate the center coordinates for val/test: divide the volumes into patches by output_patch_size.
        '''
        
        centers = []
        if self.sample_method == 'train': # train: sample more brain patches for training
            for i, mask in enumerate(self.masks):
                X, Y, Z = mask.shape
                x, y, z = np.where(mask)
                idx = (x % self.sample_gap == 0) * (y % self.sample_gap == 0) * (z % self.sample_gap == 0)
                centers += [[i, (xx, yy, zz)] for xx, yy, zz in zip(x[idx], y[idx], z[idx])]
                # add background (zero) samples
                if self.bg_ratio > 0:
                    bx, by, bz = np.where(mask == 0)
                    bg_step = max(1, int(len(bx) // (idx.sum() * self.bg_ratio)))
                    centers += [[i, (xx, yy, zz)] for xx, yy, zz in zip(bx[::bg_step], by[::bg_step], bz[::bg_step])]
        else: # other: split into equal patches
            for i, img in enumerate(self.inputs): # loop every scan
                X, Y, Z = img.shape
                x0, y0, z0 = (self.output_patch_size / 2).astype(int) # start location (half of output patch size)
                xs, ys, zs = self.output_patch_size.astype(int) # step size
                for x in range(x0, X+x0+1, xs):
                    for y in range(y0, Y+y0+1, ys):
                        for z in range(z0, Z+z0+1, zs):
                            centers.append([i, (x,y,z)]) # [index, center_coordinates]
        return centers
    
    def _get_patch(self, mat, center, patch_size):
        '''
        Get patch by the center coordinates.
        '''
        
        def _calc_coordinates(c, p, m):
            '''
            Calculate the relative coordinates of patches
            Input: c-center, p-patch size, m-mat size
            Output: ml-left coordinate in matrix, mr-right..., pl-left coordinate in patch, pr-right...
            
            Note: all input/output are integers
            '''
            L, R = c - p // 2, c + p // 2
            ml = max(L, 0)
            mr = min(m, R)
            pl = 0 if L >= 0 else abs(L)
            pr = p if R <= m else p - (R - m)
            return ml, mr, pl, pr
        
        patch = np.zeros(patch_size)
        
        ml1, mr1, pl1, pr1 = _calc_coordinates(center[0], patch_size[0], mat.shape[0])
        ml2, mr2, pl2, pr2 = _calc_coordinates(center[1], patch_size[1], mat.shape[1])
        ml3, mr3, pl3, pr3 = _calc_coordinates(center[2], patch_size[2], mat.shape[2])
        
        patch[pl1:pr1, pl2:pr2, pl3:pr3] = mat[ml1:mr1, ml2:mr2, ml3:mr3]
        return patch
    
    
    def _data_transform_func(self, input, target):
        if np.random.rand() > 0.5:
            input, target = torch.flip(input, [1]), torch.flip(target, [1])
        if np.random.rand() > 0.5:
            input, target = torch.flip(input, [2]), torch.flip(target, [2])
        if np.random.rand() > 0.5:
            input, target = torch.flip(input, [3]), torch.flip(target, [3])
        return input, target

    
    def __len__(self):
        '''
        Return the length of the dataset, i.e. the number of patches.
        '''
        return len(self.centers)

    
    def __getitem__(self, idx):
        '''
        Get sample by index.
        '''
        center = self.centers[idx]
        i, c = center
        input  = torch.from_numpy(self._get_patch(self.inputs[i], c, self.input_patch_size[0]) 
                                  * self.input_scale).unsqueeze(0).float()
        target = torch.from_numpy(self._get_patch(self.outputs[i], c, self.output_patch_size) 
                                  * self.output_scale).unsqueeze(0).float()
        target = self.output_transform(target)
        if len(self.input_patch_size) == 2:
            input_patch_large = torch.from_numpy(self._get_patch(self.inputs[i], c, self.input_patch_size[1]) 
                                                 * self.input_scale).unsqueeze(0).float()
            input = (input, input_patch_large)
        if self.data_transform:
            input, target = self._data_transform_func(input, target)
        return input, target, torch.Tensor([i]), torch.Tensor(c)


    
class QsmPatchDataHD(Dataset):
    
    def __init__(self, 
                 nifti_files, 
                 input_patch_size, 
                 output_patch_size,
                 input_scale=100, 
                 output_scale=100, 
                 output_transform='tanh'):
        '''
        Dataset for Huntington's project subjects.
        '''
        self.ZOOM_SCALE = np.array([1, 1, 1/0.8]) # for (0.8, 0.8, 1) resolution HD scans
        
        self.input_patch_size = np.array(input_patch_size)
        if self.input_patch_size.ndim == 1:
            self.input_patch_size = np.expand_dims(self.input_patch_size, 0)
        if len(self.input_patch_size) == 2:
            if self.input_patch_size[0,0] > self.input_patch_size[1,0]:
                self.input_patch_size = self.input_patch_size[::-1,:] # 0-small, 1-large

        self.output_patch_size = np.array(output_patch_size)
        self.data = []
        try:
            for f in nifti_files:
                self.data.append(nib.load(f))
        except:
            raise ValueError(f'Reading {f} failed!')
        
        self.inputs = [d.get_data() for d in self.data]
        self.original_sizes = [d.shape for d in self.inputs]
        # interpolate to 0.8mm isotropic resolution
        self.inputs = [zoom(d, self.ZOOM_SCALE) for d in self.inputs]
        self.interpolated_sizes = [d.shape for d in self.inputs]

        self.input_scale = input_scale
        self.output_scale = output_scale
        self.sample_method = 'other'
 
        self.centers = self._calc_centers()
        self.output_transform = np.tanh if output_transform == 'tanh' else lambda x: x
        
    
    def _calc_centers(self):
        '''
        Calculate the center coordinates for val/test: divide the volumes into patches by output_patch_size.
        '''
        
        centers = []
        if self.sample_method == 'train': # train: sample more brain patches for training
            for i, mask in enumerate(self.masks):
                X, Y, Z = mask.shape
                x, y, z = np.where(mask)
                idx = (x % self.sample_gap == 0) * (y % self.sample_gap == 0) * (z % self.sample_gap == 0)
                centers += [[i, (xx, yy, zz)] for xx, yy, zz in zip(x[idx], y[idx], z[idx])]
                # add background (zero) samples
                if self.bg_ratio > 0:
                    bx, by, bz = np.where(mask == 0)
                    bg_step = max(1, int(len(bx) // (idx.sum() * self.bg_ratio)))
                    centers += [[i, (xx, yy, zz)] for xx, yy, zz in zip(bx[::bg_step], by[::bg_step], bz[::bg_step])]
        else: # other: split into equal patches
            for i, img in enumerate(self.inputs): # loop every scan
                X, Y, Z = img.shape
                x0, y0, z0 = (self.output_patch_size / 2).astype(int) # start location (half of output patch size)
                xs, ys, zs = self.output_patch_size.astype(int) # step size
                for x in range(x0, X+x0+1, xs):
                    for y in range(y0, Y+y0+1, ys):
                        for z in range(z0, Z+z0+1, zs):
                            centers.append([i, (x,y,z)]) # [index, center_coordinates]
        return centers
    
    def _get_patch(self, mat, center, patch_size):
        '''
        Get patch by the center coordinates.
        '''
        
        def _calc_coordinates(c, p, m):
            '''
            Calculate the relative coordinates of patches
            Input: c-center, p-patch size, m-mat size
            Output: ml-left coordinate in matrix, mr-right..., pl-left coordinate in patch, pr-right...
            
            Note: all input/output are integers
            '''
            L, R = c - p // 2, c + p // 2
            ml = max(L, 0)
            mr = min(m, R)
            pl = 0 if L >= 0 else abs(L)
            pr = p if R <= m else p - (R - m)
            return ml, mr, pl, pr
        
        patch = np.zeros(patch_size)
        
        ml1, mr1, pl1, pr1 = _calc_coordinates(center[0], patch_size[0], mat.shape[0])
        ml2, mr2, pl2, pr2 = _calc_coordinates(center[1], patch_size[1], mat.shape[1])
        ml3, mr3, pl3, pr3 = _calc_coordinates(center[2], patch_size[2], mat.shape[2])
        
        patch[pl1:pr1, pl2:pr2, pl3:pr3] = mat[ml1:mr1, ml2:mr2, ml3:mr3]
        return patch
    
    
    def __len__(self):
        '''
        Return the length of the dataset, i.e. the number of patches.
        '''
        return len(self.centers)

    
    def __getitem__(self, idx):
        '''
        Get sample by index.
        '''
        center = self.centers[idx]
        i, c = center
        input  = torch.from_numpy(self._get_patch(self.inputs[i], c, self.input_patch_size[0]) 
                                  * self.input_scale).unsqueeze(0).float()
        return input, torch.Tensor([i]), torch.Tensor(c)
    

class QsmPatchDataBtumor(Dataset):
    
    def __init__(self, 
                 nifti_files, 
                 input_patch_size, 
                 output_patch_size,
                 input_scale=100, 
                 output_scale=100, 
                 output_transform='tanh'):
        '''
        Dataset for 7T brain tumor subjects.
        '''
        self.input_patch_size = np.array(input_patch_size)
        if self.input_patch_size.ndim == 1:
            self.input_patch_size = np.expand_dims(self.input_patch_size, 0)
        if len(self.input_patch_size) == 2:
            if self.input_patch_size[0,0] > self.input_patch_size[1,0]:
                self.input_patch_size = self.input_patch_size[::-1,:] # 0-small, 1-large

        self.output_patch_size = np.array(output_patch_size)
        self.data = []
        try:
            for f in nifti_files:
                self.data.append(nib.load(f))
        except:
            raise ValueError(f'Reading {f} failed!')
        
        self.inputs = [d.get_data() for d in self.data]
        self.original_sizes = [d.shape for d in self.inputs]
        self.interpolated_sizes = [d.shape for d in self.inputs]

        self.input_scale = input_scale
        self.output_scale = output_scale
        self.sample_method = 'other'
 
        self.centers = self._calc_centers()
        self.output_transform = np.tanh if output_transform == 'tanh' else lambda x: x
        
    
    def _calc_centers(self):
        '''
        Calculate the center coordinates for val/test: divide the volumes into patches by output_patch_size.
        '''
        
        centers = []
        if self.sample_method == 'train': # train: sample more brain patches for training
            for i, mask in enumerate(self.masks):
                X, Y, Z = mask.shape
                x, y, z = np.where(mask)
                idx = (x % self.sample_gap == 0) * (y % self.sample_gap == 0) * (z % self.sample_gap == 0)
                centers += [[i, (xx, yy, zz)] for xx, yy, zz in zip(x[idx], y[idx], z[idx])]
                # add background (zero) samples
                if self.bg_ratio > 0:
                    bx, by, bz = np.where(mask == 0)
                    bg_step = max(1, int(len(bx) // (idx.sum() * self.bg_ratio)))
                    centers += [[i, (xx, yy, zz)] for xx, yy, zz in zip(bx[::bg_step], by[::bg_step], bz[::bg_step])]
        else: # other: split into equal patches
            for i, img in enumerate(self.inputs): # loop every scan
                X, Y, Z = img.shape
                x0, y0, z0 = (self.output_patch_size / 2).astype(int) # start location (half of output patch size)
                xs, ys, zs = self.output_patch_size.astype(int) # step size
                for x in range(x0, X+x0+1, xs):
                    for y in range(y0, Y+y0+1, ys):
                        for z in range(z0, Z+z0+1, zs):
                            centers.append([i, (x,y,z)]) # [index, center_coordinates]
        return centers
    
    def _get_patch(self, mat, center, patch_size):
        '''
        Get patch by the center coordinates.
        '''
        
        def _calc_coordinates(c, p, m):
            '''
            Calculate the relative coordinates of patches
            Input: c-center, p-patch size, m-mat size
            Output: ml-left coordinate in matrix, mr-right..., pl-left coordinate in patch, pr-right...
            
            Note: all input/output are integers
            '''
            L, R = c - p // 2, c + p // 2
            ml = max(L, 0)
            mr = min(m, R)
            pl = 0 if L >= 0 else abs(L)
            pr = p if R <= m else p - (R - m)
            return ml, mr, pl, pr
        
        patch = np.zeros(patch_size)
        
        ml1, mr1, pl1, pr1 = _calc_coordinates(center[0], patch_size[0], mat.shape[0])
        ml2, mr2, pl2, pr2 = _calc_coordinates(center[1], patch_size[1], mat.shape[1])
        ml3, mr3, pl3, pr3 = _calc_coordinates(center[2], patch_size[2], mat.shape[2])
        
        patch[pl1:pr1, pl2:pr2, pl3:pr3] = mat[ml1:mr1, ml2:mr2, ml3:mr3]
        return patch
    
    
    def __len__(self):
        '''
        Return the length of the dataset, i.e. the number of patches.
        '''
        return len(self.centers)

    
    def __getitem__(self, idx):
        '''
        Get sample by index.
        '''
        center = self.centers[idx]
        i, c = center
        input  = torch.from_numpy(self._get_patch(self.inputs[i], c, self.input_patch_size[0]) 
                                  * self.input_scale).unsqueeze(0).float()
        return input, torch.Tensor([i]), torch.Tensor(c)
    
    
def build_data_generator(dataloader):
    while True:
        for data in dataloader:
            yield data
            
            
