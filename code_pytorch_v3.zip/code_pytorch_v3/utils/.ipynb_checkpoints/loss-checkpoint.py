import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable

def GradLoss(output, target, device):
    """
    Image gradient loss using 3D Sobel operator
    """
    def grad(input, dim):
    
        with torch.no_grad():
            # build the operator
            op1 = torch.Tensor([[1,2,1],[2,4,2],[1,2,1]]) # 3D Sobel operator
            op2 = torch.zeros_like(op1)
            op3 = -op1
            op = torch.stack([op1, op2, op3]).to(device)

            # switch dimensions accordingly
            if dim == 1:
                op = op.permute([2,1,0])
            elif dim == 2:
                op = op.permute([2,0,1])
            else:
                pass

            # calculate gradient through convolution
            grad = F.conv3d(Variable(input), Variable(op.unsqueeze(0).unsqueeze(0)), padding = 1)

        return grad.squeeze()
    
    go0, go1, go2 = grad(output, 0), grad(output, 1), grad(output, 2)
    to0, to1, to2 = grad(target, 0), grad(target, 1), grad(target, 2)
    return torch.mean(torch.abs(to0-go0) + torch.abs(to1-go1) + torch.abs(to2-go2)) # 2/26/19 - change from sum to mean


class L1GradLoss(nn.Module):
    """
    L1 + Gradient loss.
    """
    def __init__(self, lambda_l1=1, lambda_grad=0.5, device='cpu'):
        super(L1GradLoss, self).__init__()
        self.lambda_l1 = lambda_l1
        self.lambda_grad = lambda_grad
        self.device = device
        
    def forward(self, output, target):
        loss = F.l1_loss(output, target) * self.lambda_l1
        if self.lambda_grad > 0:
            loss += GradLoss(output, target, self.device) * self.lambda_grad
        return loss

class L1L2Loss(nn.Module):
    """
    L1 + L2 loss.
    """
    def __init__(self, lambda_l1=1, lambda_l2=1):
        super(L1L2Loss, self).__init__()
        self.lambda_l1 = lambda_l1
        self.lambda_l2 = lambda_l2
        
    def forward(self, output, target):
        l1_loss = F.l1_loss(output, target) * self.lambda_l1
        l2_loss = F.mse_loss(output, target) * self.lambda_l2
        return l1_loss + l2_loss
        